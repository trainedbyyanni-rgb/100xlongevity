# 100X Yanni — Site Rebuild Instructions for Claude Code

Work through these in order. Each step should be a separate commit so
changes can be reviewed and rolled back independently. Do not skip
ahead to the blog rebuild before the CSS foundation is merged, since
later steps assume the new tokens/utilities exist.

## Step 0 — Merge the CSS foundation
- Open `design-system-additions.css` (provided alongside this file).
- Merge its contents into `assets/style.css`. Do not simply append it;
  fold each section in near related existing rules, and remove any
  now-duplicated inline `<style>` blocks in individual HTML files as
  you touch them in later steps.
- Confirm existing color/spacing values elsewhere in the CSS get
  replaced with the new `var(--...)` tokens rather than left as
  hardcoded duplicates.
- Reserve `--color-citation` (#0066cc) strictly for citation links.
  Do not apply it to nav, buttons, or any other element.

## Step 1 — Nav pattern
- Replace the current top bar markup on every page with the
  `.site-nav` edge-tucked pattern (mark top-left, links top-right,
  mobile toggle + full-screen overlay under 640px).
- Test at 375px, 768px, and 1440px widths.

## Step 2 — Cognitive hub cleanup
- Audit all ~17 cards in `cognitive/index.html`.
- Confirmed real lessons: acetylcholine.html, bdnf.html, ssri.html,
  amphetamines.html, wakefulness.html. Everything else becomes a
  "Coming Soon" card: same visual treatment, but non-clickable (or
  linking nowhere) and visually marked as unavailable, e.g. a small
  greyed "Coming Soon" label using `--color-grey-light`.
- Do not delete the roadmap cards, just neutralize the broken links.

## Step 3 — sources.html rebuild
- Remove all old peptide/compound citation entries.
- Pull citations only from the 5 real lesson pages listed above.
- Group by lesson, cited in the same order they appear in each lesson.
- Do not invent, reformat, or "fill in" any citation. If a lesson's
  citation list can't be cleanly extracted, flag it instead of
  guessing.

## Step 4 — Blog rebuild (biggest structural change)
- Current state: `admin.html` writes posts to `localStorage`, so posts
  never reach the actual filesystem and are invisible to Google and to
  anyone not on Yanni's own browser.
- New approach: each post becomes a real static `.html` file in
  `blog/`, generated from `blog/post-template.html`.
- `admin.html` can stay as a local authoring convenience if useful,
  but it must output a real `.html` file (e.g. via a manual copy/paste
  workflow or a local build script), not localStorage writes.
- `blog/index.html` should list posts by reading the actual files in
  `blog/`, not a localStorage index.
- Apply the new hero/spacing/nav rules to the template and to
  `blog/index.html`.

## Step 5 — Coaching CTA
- Placeholder: swap `href="#"` on the coaching page CTA for the real
  Tally form URL once Yanni provides it. Leave a clear `<!-- TODO:
  Tally URL -->` marker if it's not available yet, don't leave it as
  a silent dead link.

## Step 6 — Mobile pass (cross-cutting, do last)
- Sweep every page at 375px width after the above steps are in.
- Confirm: no horizontal scroll, images scale via the new `img, svg,
  video { max-width: 100% }` rule, multi-column grids collapse to
  single column under 640px, nav overlay opens/closes cleanly.

## Constraints that apply to every step
- No shadows, gradients, or rounded corners anywhere.
- No stock photography, no testimonials, no pricing on coaching.html.
- Medical disclaimer stays in every footer, unchanged.
- Never invent a citation, PubMed ID, or YouTube video ID. The only
  confirmed valid video ID is `g7FVEpNlcwI`.
- Blue (`--color-citation`) appears only on citation links, nowhere
  else on the site.
